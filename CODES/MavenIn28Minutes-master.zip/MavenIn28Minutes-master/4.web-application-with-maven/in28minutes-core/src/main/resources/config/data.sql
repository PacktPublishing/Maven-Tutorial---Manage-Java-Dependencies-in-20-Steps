--users
INSERT INTO user VALUES (1,'UserName','user@in28minutes.com', 'password');

--todos

INSERT INTO todoitem VALUES (1,1,'Learn Spring', true, 1,'2015-10-25');
INSERT INTO todoitem VALUES (2,1,'Learn Spring MVC', true, 1,'2015-10-30');
INSERT INTO todoitem VALUES (3,1,'Learn Hibernate', false, 2,'2015-11-11');
INSERT INTO todoitem VALUES (5,1,'Learn to Dance', false, 0,'2015-11-15');
INSERT INTO todoitem VALUES (6,1,'Prepare for interview', true, 0,'2015-12-12');